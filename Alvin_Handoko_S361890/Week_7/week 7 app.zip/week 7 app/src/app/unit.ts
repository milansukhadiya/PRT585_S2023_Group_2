export interface Unit {
    UnitId : number;
    UnitName: string;
    UnitCode: string;
}
