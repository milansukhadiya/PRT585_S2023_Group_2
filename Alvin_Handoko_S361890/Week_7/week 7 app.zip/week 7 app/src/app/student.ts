export interface Student {
    StudentId : number;
    StudentName: string;
}
